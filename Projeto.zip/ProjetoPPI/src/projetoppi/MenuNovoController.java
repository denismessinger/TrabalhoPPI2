/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoppi;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;

/**
 *
 * @author Seven
 */
public class MenuNovoController implements Initializable {
    
    @FXML private Button home;
    @FXML private Button calendario;
    @FXML private Button manualf;
    @FXML private Button lista;
    @FXML private Button sair;
    @FXML private VBox painel;
    @FXML private Button produtividade;
    @FXML private Button usuarios; 
    @FXML private Button programa;
    @FXML private Button mpt;
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }
    
    @FXML void calendario(ActionEvent event) throws IOException {
        VBox painell = FXMLLoader.load(getClass().getResource("Novo.fxml"));
        painel.getChildren().setAll(painell);
    }

    @FXML void carregar(ActionEvent event) throws IOException {
        Parent fxmlMenus = FXMLLoader.load(getClass().getResource("MenuNovo.fxml"));
        Scene Menuscene = new Scene(fxmlMenus, 991, 613);
        ProjetoPPI.stage.setScene(Menuscene);
        ProjetoPPI.stage.show();
    }

    @FXML void listas(ActionEvent event) throws IOException {
        VBox painell = FXMLLoader.load(getClass().getResource("Listas.fxml"));
        painel.getChildren().setAll(painell);
    }

    @FXML
    void manuais(ActionEvent event) throws IOException {
        VBox painell = FXMLLoader.load(getClass().getResource("ManuaisMenu.fxml"));
        painel.getChildren().setAll(painell);
    }

    @FXML
    void produtividade(ActionEvent event) throws IOException {
        VBox painell = FXMLLoader.load(getClass().getResource("Produtividade.fxml"));
        painel.getChildren().setAll(painell);
    }

    @FXML
    void usuarios(ActionEvent event) throws IOException {
        if(ProjetoPPI.usuario.getPermissao()!=1){
            Alert dialogoInfo = new Alert(Alert.AlertType.INFORMATION);
            dialogoInfo.setTitle("Campo Inválido");
            dialogoInfo.setContentText("Você não tem permissão para isso!");
            dialogoInfo.showAndWait();
        }else{
            VBox painell = FXMLLoader.load(getClass().getResource("Usuarios.fxml"));
            painel.getChildren().setAll(painell);
        }
    }
    @FXML
    void mpt(ActionEvent event) throws IOException {
        VBox painell = FXMLLoader.load(getClass().getResource("MPT.fxml"));
        painel.getChildren().setAll(painell);
    }
    @FXML
    void programa(ActionEvent event) throws IOException {
        VBox painell = FXMLLoader.load(getClass().getResource("Programacao.fxml"));
        painel.getChildren().setAll(painell);
    }
    @FXML
    void sair(ActionEvent event) {
        System.exit(0);
    }
}
