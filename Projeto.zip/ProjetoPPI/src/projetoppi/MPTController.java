/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoppi;

import java.net.URL;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import projeto_ppi.dao.MptDAO;
import projeto_ppi.pojo.Calendario;
import projeto_ppi.pojo.MPT;
/**
 * FXML Controller class
 *
 * @author Seven
 */
public class MPTController implements Initializable {
    
    @FXML private TableView<MPT> tabela;
    @FXML private TableColumn<MPT, String> descricao1;
    @FXML private TableColumn<MPT, String> maquina1;
    @FXML private TableColumn<MPT, String> responsavel1;
    @FXML private TableColumn<MPT, String> limite1;
    @FXML private TableColumn<MPT, String> realizado1;
    @FXML private Pane botoes;
    @FXML private Button adicionar;
    @FXML private Button excluir;
    @FXML private Button editar;
    @FXML private Pane formulario;
    @FXML private TextField descricao;
    @FXML private ComboBox<String> maquina;
    @FXML private ComboBox<String> responsavel;
    @FXML private DatePicker limite;
    @FXML private Button pronto;
    @FXML private Button cancelar;
    @FXML private DatePicker realizado;
    @FXML private Label realizadotext;
    private boolean add=true;
    MptDAO dao = new MptDAO();
    public List<MPT> listas = new ArrayList<>();
    public List<String> categorias = new ArrayList<>();
    public List<String> categorias2 = new ArrayList<>();
    public ObservableList<MPT> lista = FXCollections.observableArrayList();
    public ObservableList<String> cat1 = FXCollections.observableArrayList();   
    public ObservableList<String> cat2 = FXCollections.observableArrayList();   
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        descricao1.setCellValueFactory(
            new PropertyValueFactory<>("descricao"));
        maquina1.setCellValueFactory(
            new PropertyValueFactory<>("maquina"));
        responsavel1.setCellValueFactory(
            new PropertyValueFactory<>("responsavel"));
        limite1.setCellValueFactory(
            new PropertyValueFactory<>("limite"));
        realizado1.setCellValueFactory(
            new PropertyValueFactory<>("realizado"));
        carregarCategorias();
        carregarCat2();
        carregar();
    }    
    @FXML
    void adicionar(ActionEvent event) {
        botoes.setVisible(false);
        formulario.setVisible(true);
        add=true;
    }
     @FXML
    void cancelar(ActionEvent event) {
        botoes.setVisible(true);
        formulario.setVisible(false);
    }

    @FXML
    void editar(ActionEvent event) {
        botoes.setVisible(false);
        formulario.setVisible(true);
        add=false;
    }

    @FXML
    void excluir(ActionEvent event) {
        MPT list = tabela.getSelectionModel().getSelectedItem();
        if(list!=null){
            try{
                dao.excluir(list.getId());
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        carregar();
    }

    @FXML
    void pronto(ActionEvent event) {
        if(add){
            if(limite.getValue()!=null & descricao.getText()!=null){
                MPT mpt = new MPT();
                mpt.setDescricao(descricao.getText());
                mpt.setLimite(limite.getValue().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
                if(realizado.getValue()!=null){
                    mpt.setRealizado(realizado.getValue().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
                }
                mpt.setMaquina(maquina.getSelectionModel().getSelectedItem());
                mpt.setResponsavel(responsavel.getSelectionModel().getSelectedItem());
                dao.salvar(mpt);
                carregar();
                botoes.setVisible(true);
                formulario.setVisible(false);
            }else{
                Alert dialogoInfo = new Alert(Alert.AlertType.INFORMATION);
                dialogoInfo.setTitle("Campo Inválido");
                dialogoInfo.setContentText("Preencha todos os campos!");
                dialogoInfo.showAndWait();
            }
        }else{
            MPT mpt = new MPT();
            mpt = (MPT)tabela.getSelectionModel().getSelectedItem();
            if(mpt!=null){
                if(limite.getValue()!=null & descricao.getText()!=null){
                    mpt.setDescricao(descricao.getText());
                    mpt.setLimite(limite.getValue().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
                    if(realizado!=null){
                        mpt.setRealizado(realizado.getValue().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
                    }
                    mpt.setMaquina(maquina.getSelectionModel().getSelectedItem());
                    mpt.setResponsavel(responsavel.getSelectionModel().getSelectedItem());
                    dao.atualizar(mpt);
                    carregar();
                    botoes.setVisible(true);
                    formulario.setVisible(false);
                }else{
                    Alert dialogoInfo = new Alert(Alert.AlertType.INFORMATION);
                    dialogoInfo.setTitle("Campo Inválido");
                    dialogoInfo.setContentText("Preencha todos os campos!");
                    dialogoInfo.showAndWait();
                }
                
            }else{
                Alert dialogoInfo = new Alert(Alert.AlertType.INFORMATION);
                dialogoInfo.setTitle("Campo Inválido");
                dialogoInfo.setContentText("Selecione uma lista para editar!");
                dialogoInfo.showAndWait();
            }
        }
    }
    
    public void carregar(){
        if(!lista.isEmpty()){
            lista.clear();
        }
        listas = dao.buscar();
        System.out.print(listas.size());
        for (MPT list : listas){
            lista.add(list);
        }
        try{
            tabela.setItems(lista);
        }catch (NullPointerException e){
            e.printStackTrace();
        }
    }
    public void carregarCategorias(){
        
        categorias.add("5868");
        categorias.add("2342");
        categorias.add("608");
        categorias.add("547");
        categorias.add("546");
        categorias.add("681");

        cat1 = FXCollections.observableArrayList(categorias);
        maquina.setItems(cat1);
    }
    public void carregarCat2(){
        categorias2.add("Mecânico");
        categorias2.add("Capitão");
        cat2 = FXCollections.observableArrayList(categorias2);
        responsavel.setItems(cat2);
    }
}
