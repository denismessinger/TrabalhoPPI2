/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoppi;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import projeto_ppi.dao.CalendarioDAO;
import projeto_ppi.dao.MptDAO;
import projeto_ppi.pojo.Calendario;
import projeto_ppi.pojo.MPT;

/**
 * FXML Controller class
 *
 * @author Seven
 */
public class ProdutividadeController implements Initializable {
    
    @FXML private BarChart<?, ?> producao;
    @FXML private CategoryAxis altera;
    @FXML private NumberAxis Total;
    @FXML private Button geral;
    @FXML private Button maquinas;
    @FXML private Button trabalho;
    @FXML private Button mpt;
    @FXML private ToggleGroup mes;
    @FXML private Button voltar;
    @FXML private Button avancar;
    @FXML private Label escrever;
    CalendarioDAO dao = new CalendarioDAO();
    MptDAO mptdao = new MptDAO();
    private String tipo="GERAL";
    private String ano="2019";
    private int escAno=2019;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        carregaTabela();
        carregaTabela();
        carregaTabela();
        carregaTabela();
        
    }
    public void carregaTabela(){
        if(tipo.equals("GERAL")){
            producao.getData().clear();
            XYChart.Series set = new XYChart.Series<>();
            set.getData().add(new XYChart.Data("Serviços Feitos", carregaTotal()));
            set.getData().add(new XYChart.Data("MPTS Realizados", carregaMPT()));
            producao.getData().addAll(set);
        }else if(tipo.equals("MAQUINAS")){
            producao.getData().clear();
            XYChart.Series set = new XYChart.Series<>();
            set.getData().add(new XYChart.Data("2342", carregaPorMaquina("2342")));
            set.getData().add(new XYChart.Data("5868", carregaPorMaquina("5868")));
            set.getData().add(new XYChart.Data("608", carregaPorMaquina("608")));
            set.getData().add(new XYChart.Data("547", carregaPorMaquina("547")));
            set.getData().add(new XYChart.Data("681", carregaPorMaquina("681")));
            set.getData().add(new XYChart.Data("546", carregaPorMaquina("546")));
            producao.getData().addAll(set);
        }else if(tipo.equals("TRABALHO")){
            producao.getData().clear();
            XYChart.Series set = new XYChart.Series<>();
            set.getData().add(new XYChart.Data("Textura", carregaPorTrabalho("Textura")));
            set.getData().add(new XYChart.Data("Roscas", carregaPorTrabalho("Roscas")));
            set.getData().add(new XYChart.Data("Stackmold", carregaPorTrabalho("Stackmold")));
            set.getData().add(new XYChart.Data("Solda", carregaPorTrabalho("Solda")));
            set.getData().add(new XYChart.Data("Furação", carregaPorTrabalho("Furação")));
            set.getData().add(new XYChart.Data("Profissional", carregaPorTrabalho("Profissional")));
            set.getData().add(new XYChart.Data("Lâminas", carregaPorTrabalho("Lâminas")));
            producao.getData().addAll(set);
        }
    }
    public int carregaPorMaquina(String maquina) throws NullPointerException{
        int enviar = 0;
        List<Calendario> lista = new ArrayList<>();
        lista = dao.buscar();
        ToggleButton selecionado = (ToggleButton) mes.getSelectedToggle();
        for(int i=0;i<lista.size();i++){
            if(lista.get(i).getEntrega()!=null){
                String teste = lista.get(i).getEntrega();
                String[] retorno = teste.split("-");
                if(retorno[1].equals(selecionado.getAccessibleText())){
                    if(retorno[2].equals(ano)){
                        if(lista.get(i).getMaquina().equals(maquina)){
                            enviar++;
                        }
                    }
                }
            }
        }
        return enviar;
    }
    
    public int carregaPorTrabalho(String trabalho) throws NullPointerException{
        int enviar = 0;
        List<Calendario> lista = new ArrayList<>();
        lista = dao.buscar();
        ToggleButton selecionado = (ToggleButton) mes.getSelectedToggle();
        for(int i=0;i<lista.size();i++){
            if(lista.get(i).getEntrega()!=null){
                String teste = lista.get(i).getEntrega();
                String[] retorno = teste.split("-");
                if(retorno[1].equals(selecionado.getAccessibleText())){
                    System.out.println(retorno[2]);
                    if(retorno[2].equals(ano)){
                        System.out.println(lista.get(i).getDescricao());
                        if(lista.get(i).getDescricao().equals(trabalho)){
                            enviar++;
                        }
                    }

                }
            }
        }
        return enviar;
    }
    public int carregaTotal() throws NullPointerException{
        int enviar = 0;
        List<Calendario> lista = new ArrayList<>();
        lista = dao.buscar();
        ToggleButton selecionado = (ToggleButton) mes.getSelectedToggle();
        for(int i=0;i<lista.size();i++){
            if(lista.get(i).getEntrega()!=null){
                String teste = lista.get(i).getEntrega();
                String[] retorno = teste.split("-");
                if(retorno[1].equals(selecionado.getAccessibleText())){
                    if(retorno[2].equals(ano)){
                        enviar++;
                    }
                }
            }
        }
        return enviar;
    }
    public int carregaMPT() throws NullPointerException{
        int enviar = 0;
        List<MPT> lista = new ArrayList<>();
        lista = mptdao.buscar();
        ToggleButton selecionado = (ToggleButton) mes.getSelectedToggle();
        for(int i=0;i<lista.size();i++){
            if(lista.get(i).getRealizado()!=null){
                String teste = lista.get(i).getRealizado();
                String[] retorno = teste.split("-");
                if(retorno[1].equals(selecionado.getAccessibleText())){
                    if(retorno[2].equals(ano)){
                        enviar++;
                    }
                }
            }
        }
        return enviar;
    }
    @FXML
    void geral(ActionEvent event) {
        tipo = "GERAL";
        carregaTabela();
    }

    @FXML
    void maquinas(ActionEvent event) {
        tipo = "MAQUINAS";
        carregaTabela();
    }

    @FXML
    void trabalho(ActionEvent event) {
        tipo = "TRABALHO";
        carregaTabela();
    }
    @FXML
    void avancar(ActionEvent event) {
        escAno++;
        escrever.setText("PRODUÇÃO " + (escAno));
        ano = Integer.toString(escAno);
        System.out.println(escAno);
        carregaTabela();
        if(escAno == 2029){
            avancar.setVisible(false);
        }else if(escAno == 2020){
            voltar.setVisible(true);
        }
    }
    @FXML
    void voltar(ActionEvent event) {
        escAno--;
        escrever.setText("PRODUÇÃO " + (escAno));
        ano = Integer.toString(escAno);
        carregaTabela();
        System.out.println(escAno);
        if(escAno == 2028){
            avancar.setVisible(true);
        }else if(escAno == 2019){
            voltar.setVisible(false);
        }
    }
    @FXML
    void familia(ActionEvent event) {
        carregaTabela();
    }
}
