/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoppi;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import projeto_ppi.dao.UsuarioDAO;
import projeto_ppi.pojo.Usuario;

/**
 * FXML Controller class
 *
 * @author Seven
 */
public class UsuariosController implements Initializable {
    
    @FXML private TableView<Usuario> tabela;
    @FXML private Button excluir;
    @FXML private Button editar;
    @FXML private Button adicionar;    
    @FXML private Pane botoes;
    @FXML private Pane editavel;
    @FXML private TextField usuario3;
    @FXML private TextField senha;
    @FXML private Button Cancelar;
    @FXML private Button pronto;
    private boolean escolha=true;
    UsuarioDAO dao = new UsuarioDAO();
    @FXML private TableColumn<Usuario, String> usuario1;
    @FXML private TableColumn<Usuario, Integer> permissao;
    public List<Usuario> listas = new ArrayList<>();
    public ObservableList<Usuario> lista = FXCollections.observableArrayList(); 
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        usuario1.setCellValueFactory(
            new PropertyValueFactory<>("usuario"));
        permissao.setCellValueFactory(
            new PropertyValueFactory<>("permissao"));
        carregar();
    }  
    
    @FXML
    void adicionar(ActionEvent event) {
        botoes.setVisible(false);
        editavel.setVisible(true);
        escolha=true;
    }

    @FXML
    void editar(ActionEvent event){
        Usuario usu = new Usuario();
        usu = (Usuario)tabela.getSelectionModel().getSelectedItem();
        if(usu!=null){
            botoes.setVisible(false);
            editavel.setVisible(true);
            escolha=false;
        }else if(usu.getUsuario().equals("Denis")){
            Alert dialogoInfo = new Alert(Alert.AlertType.INFORMATION);
            dialogoInfo.setTitle("Campo Inválido");
            dialogoInfo.setContentText("Esse usuario não pode ser editado!");
            dialogoInfo.showAndWait();
        }else{
            Alert dialogoInfo = new Alert(Alert.AlertType.INFORMATION);
            dialogoInfo.setTitle("Campo Inválido");
            dialogoInfo.setContentText("Escolha um campo para editar!");
            dialogoInfo.showAndWait();
        }
    }

    @FXML
    void excluir(ActionEvent event) {
        Usuario list = tabela.getSelectionModel().getSelectedItem();
        if(list!=null & !"Denis".equals(list.getUsuario())){
            try{
                dao.remover(list.getId());
            }catch (Exception e){
                e.printStackTrace();
            }
        }else{
            Alert dialogoInfo = new Alert(Alert.AlertType.INFORMATION);
            dialogoInfo.setTitle("Campo Inválido");
            dialogoInfo.setContentText("Impossível excluir esse usuario!");
            dialogoInfo.showAndWait();
        }
        carregar();
    }
    @FXML
    void Cancelar(ActionEvent event) {
        botoes.setVisible(true);
        editavel.setVisible(false);
    }
    @FXML
    void pronto(ActionEvent event) {
        if(escolha){
            Usuario usu = new Usuario();
            usu = (Usuario)tabela.getSelectionModel().getSelectedItem();
            if(usuario3.getText()!=null & senha.getText()!=null){
                Usuario novo = new Usuario();
                int i=2;
                novo.setUsuario(usuario3.getText());
                novo.setSenha(senha.getText());
                novo.setPermissao(i);
                dao.salvar(novo);
                carregar();
                botoes.setVisible(true);
                editavel.setVisible(false);
            }else{
                Alert dialogoInfo = new Alert(Alert.AlertType.INFORMATION);
                dialogoInfo.setTitle("Campo Inválido");
                dialogoInfo.setContentText("Preencha todos os campos!!");
                dialogoInfo.showAndWait();
            }
        }else{
            Usuario usu = new Usuario();
            usu = (Usuario)tabela.getSelectionModel().getSelectedItem();
            if(usuario3.getText()!=null & senha.getText()!=null){
                Usuario novo = new Usuario();
                int i=2;
                novo.setUsuario(usuario3.getText());
                novo.setSenha(senha.getText());
                novo.setPermissao(i);
                dao.atualizar(novo);
                carregar();
                botoes.setVisible(true);
                editavel.setVisible(false);
            }else{
                Alert dialogoInfo = new Alert(Alert.AlertType.INFORMATION);
                dialogoInfo.setTitle("Campo Inválido");
                dialogoInfo.setContentText("Preencha todos os campos!!");
                dialogoInfo.showAndWait();
            }
        }
    }
    public void carregar(){
        if(!lista.isEmpty()){
            lista.clear();
        }
        listas = dao.buscar();
        System.out.print(listas.size());
        for (Usuario list : listas){
            lista.add(list);
        }
        try{
            tabela.setItems(lista);
        }catch (NullPointerException e){
            e.printStackTrace();
        }
    }

}
